var express = require('express');
var router = express.Router();
var model = require('../model');

/* GET home page. */
router.get('/', function(req, res, next) {
  model.connect(function(db){
    db.collection('users').find().toArray(function(err, docs){
      console.log('user list: ', docs)
      res.render('index', { title: 'Express' });
    })
  })

});

//render register page
router.get('/regist', function(req, res, next){
  res.render('regist',(''))
})

//render login page
router.get('/login', function(req, res, next){
  res.render('login',(''))
})

module.exports = router;
